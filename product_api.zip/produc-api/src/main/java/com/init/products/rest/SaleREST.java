package com.init.products.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.init.products.dao.SaleDAO;
import com.init.products.entitys.Sale;


@RestController
@RequestMapping("Sales")
public class SaleREST {
	 @Autowired
	  private SaleDAO saleDAO;
	 
	 
	  @GetMapping	
	  public ResponseEntity<List<Sale>> getSale(){
		  List<Sale> sales= saleDAO.findAll();
		  return ResponseEntity.ok(sales);
	  }	
	  
	  
	  @RequestMapping(value="{saleId}")// /sales/{saleId}
	  public ResponseEntity<Sale> getSaleById(@PathVariable("saleId") Integer saleId){
		Optional<Sale> optionalSale=  saleDAO.findById(saleId);
		if(optionalSale.isPresent()) {
			
			return ResponseEntity.ok(optionalSale.get());
		}else {
			return ResponseEntity.noContent().build();
		}
		  
	  }
	  
	  @PostMapping
	  public ResponseEntity<Sale> createSale(@RequestBody Sale sale){
		  Sale newSale= saleDAO.save(sale);
		  return ResponseEntity.ok(newSale);
	  }
	  
	  @DeleteMapping(value="{saleId}")
	  public ResponseEntity<Void> deleteSale(@PathVariable("saleId") Integer saleId){
		  saleDAO.deleteById(saleId);
		  return ResponseEntity.ok(null);
	  }
	  
	  @PutMapping
	  public ResponseEntity<Sale> updateSale(@RequestBody Sale sale){
		  
		  Optional<Sale> optionalSale=  saleDAO.findById(sale.getId());
			if(optionalSale.isPresent()) {
				
				Sale updateSale= optionalSale.get();
				updateSale.setFecha(sale.getFecha());
				updateSale.setId_usuario(sale.getId_usuario());
				updateSale.setTotal(sale.getTotal());
				saleDAO.save(updateSale);
				return ResponseEntity.ok(updateSale);
			}else {
				return ResponseEntity.notFound().build();
			}
		  
		  
	  }
	 
}
