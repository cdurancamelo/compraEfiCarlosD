package com.init.products.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.init.products.entitys.Concept;

public interface ConceptDAO extends JpaRepository<Concept, Integer> {

}
