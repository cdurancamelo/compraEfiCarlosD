package com.init.products.entitys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ventap")
public class Sale {
	    @Id
	    @Column(name="id")
	    @GeneratedValue(strategy=GenerationType.IDENTITY)
		private int id;
	    
	    @Column(name="fecha", nullable=false)
	    private Date fecha;
	    
	    @Column(name="id_usuario", nullable=false)
	    private int id_usuario;
	  
	    @Column(name="total")
	    private Long total;
	   
	    public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public Date getFecha() {
			return fecha;
		}


		public void setFecha(Date fecha) {
			this.fecha = fecha;
		}


		public int getId_usuario() {
			return id_usuario;
		}


		public void setId_usuario(int id_usuario) {
			this.id_usuario = id_usuario;
		}


		public Long getTotal() {
			return total;
		}


		public void setTotal(Long total) {
			this.total = total;
		}

	  
}
