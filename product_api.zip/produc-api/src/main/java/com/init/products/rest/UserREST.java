package com.init.products.rest;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.init.products.dao.UserDAO;
import com.init.products.entitys.User;

@RestController
@RequestMapping("users")
public class UserREST {
  @Autowired
  private UserDAO userDAO;
  
  @GetMapping	
  public ResponseEntity<List<User>> getUser(){
	  List<User> users= userDAO.findAll();
	  return ResponseEntity.ok(users);
  }	
  
  @RequestMapping(value="{userId}")// /users/{userId}
  public ResponseEntity<User> getUserById(@PathVariable("userId") Integer userId){
	Optional<User> optionalUser=  userDAO.findById(userId);
	if(optionalUser.isPresent()) {
		
		return ResponseEntity.ok(optionalUser.get());
	}else {
		return ResponseEntity.noContent().build();
	}
	  
  }
  
 
  
  
  @PostMapping
  public ResponseEntity<User> createUser(@RequestBody User user){
	  User newUser= userDAO.save(user);
	  return ResponseEntity.ok(newUser);
  }
  @DeleteMapping(value="{userId}")
  public ResponseEntity<Void> deleteUser(@PathVariable("userId") Integer userId){
	  userDAO.deleteById(userId);
	  return ResponseEntity.ok(null);
  }
  
  
  @PutMapping
  public ResponseEntity<User> updateUser(@RequestBody User user){
	  
	  Optional<User> optionalUser=  userDAO.findById(user.getId());
		if(optionalUser.isPresent()) {
			
			User updateUser= optionalUser.get();
			updateUser.setEmail(user.getEmail());
			updateUser.setPassword(user.getPassword());
			updateUser.setNombre(user.getNombre());
			
			userDAO.save(updateUser);
			return ResponseEntity.ok(updateUser);
		}else {
			return ResponseEntity.notFound().build();
		}
	  
	  
  }
  
  
  
  
  
  
}
