package com.init.products.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.init.products.dao.ConceptDAO;

import com.init.products.entitys.Concept;


@RestController
@RequestMapping("concepts")
public class ConceptREST {
	@Autowired
	private ConceptDAO conceptDAO;
	
	  @GetMapping	
	  public ResponseEntity<List<Concept>> getConcept(){
		  List<Concept> concepts= conceptDAO.findAll();
		  return ResponseEntity.ok(concepts);
	  }	
	  
	  @RequestMapping(value="{conceptId}")// /products/{productId}
	  public ResponseEntity<Concept> getConceptById(@PathVariable("conceptId") Integer conceptId){
		Optional<Concept> optionalConcept=  conceptDAO.findById(conceptId);
		if(optionalConcept.isPresent()) {
			
			return ResponseEntity.ok(optionalConcept.get());
		}else {
			return ResponseEntity.noContent().build();
		}
		  
	  }
	  
	  @PostMapping
	  public ResponseEntity<Concept> createConcept(@RequestBody Concept concept){
		  Concept newConcept= conceptDAO.save(concept);
		  return ResponseEntity.ok(newConcept);
	  }
	  
	  @DeleteMapping(value="{conceptId}")
	  public ResponseEntity<Void> deleteConcept(@PathVariable("conceptId") Integer conceptId){
		  conceptDAO.deleteById(conceptId);
		  return ResponseEntity.ok(null);
	  }
	  
	  @PutMapping
	  public ResponseEntity<Concept> updateConcept(@RequestBody Concept concept){
		  
		  Optional<Concept> optionalConcept=  conceptDAO.findById(concept.getId());
			if(optionalConcept.isPresent()) {
				
				Concept updateConcept= optionalConcept.get();
				updateConcept.setId_venta(concept.getId_venta());
				updateConcept.setCantidad(concept.getCantidad());
				updateConcept.setPrecioUnitario(concept.getPrecioUnitario());
				updateConcept.setImporte(concept.getImporte());
				updateConcept.setId_producto(concept.getId_producto());
				conceptDAO.save(updateConcept);
				return ResponseEntity.ok(updateConcept);
			}else {
				return ResponseEntity.notFound().build();
			}
		  
		  
	  }

}
